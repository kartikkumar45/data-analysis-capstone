# Comprehensive Data Analysis: Cleaning, Visualization, and Predictive Modeling

**Author:** Kartik Kumar
**Type:** Data analysis capstone project (Weeks 1–4)

## Overview

This repository consolidates a four-week data analysis training sequence into three self-contained phases, each using the public dataset best suited to the technique it demonstrates:

| Phase | Technique | Dataset | Size |
|---|---|---|---|
| I | Data cleaning & preliminary analysis | Motor Trend Car Road Tests (`mtcars`) | 32 × 12 |
| II | Data visualization & insight communication | Gapminder (1952–2007) | 1,704 × 6 |
| III | Statistical analysis & predictive modeling | Breast Cancer Wisconsin (Diagnostic) | 569 × 31 |

The full narrative report — including all charts, tables, statistical interpretation, and business discussion — is in [`report/`](./report). This repository contains the underlying, annotated R source code referenced throughout that report.

## Repository Structure

```
├── phase1_data_cleaning/
│   └── data_cleaning.R          # Missing-value diagnosis, outlier treatment,
│                                 # encoding, normalization, correlation analysis
├── phase2_data_visualization/
│   └── visualization.R          # Six chart types answering distinct
│                                 # analytical questions on the Gapminder data
├── phase3_predictive_modeling/
│   ├── predictive_modeling.R    # Hypothesis testing, multicollinearity
│   │                             # diagnostics, logistic regression, random
│   │                             # forest, cross-validation, model evaluation
│   └── advanced_analysis.R      # Effect sizes, confidence intervals,
│                                 # precision-recall curves, cost-sensitive
│                                 # decision threshold analysis
└── report/
    └── Comprehensive_Data_Analysis_Report.docx
```

## How to Run

Each script is self-contained and can be run independently in R or RStudio.

```r
install.packages(c(
  "tidyverse", "corrplot", "fastDummies",   # Phase I
  "gapminder", "scales",                     # Phase II
  "caret", "car", "pROC", "randomForest", "PRROC"  # Phase III
))
```

Run in order for the full workflow:

```r
source("phase1_data_cleaning/data_cleaning.R")
source("phase2_data_visualization/visualization.R")
source("phase3_predictive_modeling/predictive_modeling.R")
source("phase3_predictive_modeling/advanced_analysis.R")
```

## Key Results

- **Phase I:** Weight is the strongest single predictor of fuel efficiency (r ≈ −0.81); a simple linear regression on weight alone explains 75.3% of the variance in mpg.
- **Phase II:** Global average life expectancy rose from 49.1 to 67.0 years between 1952 and 2007, with substantial variation in pace across continents (Asia fastest at 4.53 years/decade, Africa slowest and least linear).
- **Phase III:** Both logistic regression and random forest achieve 96.49% held-out test accuracy (95% CI [92.56%, 98.38%]) and AUC above 0.98; a cost-sensitive threshold analysis shows expected misclassification cost can be reduced by 12–13% by adjusting the decision threshold away from the conventional 0.5 default.

## Reproducibility Note

Every result in the accompanying report was independently re-verified in Python (pandas, scikit-learn, statsmodels) against the same underlying data. For Phase III, this re-execution reproduced the R output exactly — including t-statistics, VIFs, cross-validation fold accuracies, confusion matrices, and AUC values — confirming full reproducibility. See Section 2.3 of the report for details.

## License / Data Sources

All datasets used are publicly available for research and educational use. Full citations for each dataset and R package are provided in Appendix E of the report.
